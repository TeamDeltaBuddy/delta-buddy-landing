# DeltaBuddy

Telegram bot for options trading alerts and strategies.

## Backend
Python-based Telegram bot with PostgreSQL.

## Frontend
Static landing page for Vercel deployment.