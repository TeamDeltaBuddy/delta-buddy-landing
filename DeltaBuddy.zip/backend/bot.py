# Telegram bot main script
print('DeltaBuddy bot running...')