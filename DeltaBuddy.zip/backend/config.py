# Configuration file
BOT_TOKEN = 'your-telegram-bot-token'
DB_URL = 'your-postgresql-url'